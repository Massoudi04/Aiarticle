import React, { useState } from 'react';
import { PenTool, Sparkles, Globe, ImageIcon, Calendar, Send } from 'lucide-react';
import ArticlePreview from '../components/ArticlePreview';

const ArticleGenerator: React.FC = () => {
  const [formData, setFormData] = useState({
    keyword: '',
    language: 'ar',
    tone: 'professional',
    wordCount: '1000',
    includeImages: true,
    includeFaq: true,
    includeConclusion: true,
    publishNow: false,
    scheduledDate: '',
    customPrompt: ''
  });

  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedArticle, setGeneratedArticle] = useState<any>(null);

  const languages = [
    { code: 'ar', name: 'العربية', flag: '🇸🇦' },
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' }
  ];

  const tones = [
    { value: 'professional', label: 'احترافي' },
    { value: 'casual', label: 'غير رسمي' },
    { value: 'friendly', label: 'ودود' },
    { value: 'authoritative', label: 'موثوق' },
    { value: 'conversational', label: 'حواري' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleGenerate = async () => {
    setIsGenerating(true);
    
    // محاكاة عملية التوليد
    setTimeout(() => {
      const mockArticle = {
        title: formData.language === 'ar' 
          ? `دليل شامل حول ${formData.keyword}: كل ما تحتاج لمعرفته في 2024`
          : `Complete Guide to ${formData.keyword}: Everything You Need to Know in 2024`,
        content: formData.language === 'ar'
          ? `في عالم اليوم المتطور، يعتبر موضوع ${formData.keyword} من أهم المواضيع التي تشغل بال الكثيرين...`
          : `In today's evolving world, ${formData.keyword} is one of the most important topics that concern many people...`,
        language: formData.language,
        wordCount: parseInt(formData.wordCount),
        sections: [
          'مقدمة',
          'الفصل الأول: أساسيات الموضوع',
          'الفصل الثاني: التطبيق العملي',
          'الفصل الثالث: أفضل الممارسات',
          'خاتمة',
          'الأسئلة الشائعة'
        ],
        featuredImage: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg',
        generateTime: new Date().toISOString()
      };
      
      setGeneratedArticle(mockArticle);
      setIsGenerating(false);
    }, 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          مولد المقالات بالذكاء الاصطناعي
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          أنشئ مقالات احترافية عالية الجودة في دقائق معدودة
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* نموذج الإعدادات */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 border border-gray-200 dark:border-gray-700 sticky top-24">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6 flex items-center">
              <Sparkles className="h-5 w-5 text-blue-600 ml-2" />
              إعدادات المقال
            </h3>

            <div className="space-y-6">
              {/* الكلمة المفتاحية */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  الكلمة المفتاحية أو الموضوع *
                </label>
                <input
                  type="text"
                  name="keyword"
                  value={formData.keyword}
                  onChange={handleInputChange}
                  placeholder="مثال: الذكاء الاصطناعي"
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                  required
                />
              </div>

              {/* اللغة */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <Globe className="h-4 w-4 inline ml-1" />
                  اللغة
                </label>
                <select
                  name="language"
                  value={formData.language}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  {languages.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* نبرة الكتابة */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  نبرة الكتابة
                </label>
                <select
                  name="tone"
                  value={formData.tone}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  {tones.map((tone) => (
                    <option key={tone.value} value={tone.value}>
                      {tone.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* عدد الكلمات */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  عدد الكلمات
                </label>
                <select
                  name="wordCount"
                  value={formData.wordCount}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                >
                  <option value="500">500 كلمة</option>
                  <option value="1000">1000 كلمة</option>
                  <option value="1500">1500 كلمة</option>
                  <option value="2000">2000 كلمة</option>
                  <option value="3000">3000 كلمة</option>
                </select>
              </div>

              {/* خيارات إضافية */}
              <div className="space-y-3">
                <h4 className="font-medium text-gray-900 dark:text-white">خيارات إضافية</h4>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="includeImages"
                    checked={formData.includeImages}
                    onChange={handleInputChange}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="mr-2 text-sm text-gray-700 dark:text-gray-300">
                    <ImageIcon className="h-4 w-4 inline ml-1" />
                    إضافة صور
                  </span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="includeFaq"
                    checked={formData.includeFaq}
                    onChange={handleInputChange}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="mr-2 text-sm text-gray-700 dark:text-gray-300">
                    إضافة أسئلة شائعة
                  </span>
                </label>

                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="includeConclusion"
                    checked={formData.includeConclusion}
                    onChange={handleInputChange}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="mr-2 text-sm text-gray-700 dark:text-gray-300">
                    إضافة خاتمة
                  </span>
                </label>
              </div>

              {/* برومت مخصص */}
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  برومت مخصص (اختياري)
                </label>
                <textarea
                  name="customPrompt"
                  value={formData.customPrompt}
                  onChange={handleInputChange}
                  placeholder="أضف تعليمات إضافية للذكاء الاصطناعي..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                />
              </div>

              {/* خيارات النشر */}
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-900 dark:text-white mb-3">خيارات النشر</h4>
                
                <label className="flex items-center mb-3">
                  <input
                    type="checkbox"
                    name="publishNow"
                    checked={formData.publishNow}
                    onChange={handleInputChange}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="mr-2 text-sm text-gray-700 dark:text-gray-300">
                    نشر فوري في بلوجر
                  </span>
                </label>

                {!formData.publishNow && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      <Calendar className="h-4 w-4 inline ml-1" />
                      جدولة النشر
                    </label>
                    <input
                      type="datetime-local"
                      name="scheduledDate"
                      value={formData.scheduledDate}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    />
                  </div>
                )}
              </div>

              {/* زر التوليد */}
              <button
                onClick={handleGenerate}
                disabled={!formData.keyword || isGenerating}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-4 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white ml-2"></div>
                    جاري التوليد...
                  </>
                ) : (
                  <>
                    <PenTool className="h-5 w-5 ml-2" />
                    توليد المقال
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* معاينة المقال */}
        <div className="lg:col-span-2">
          {!generatedArticle && !isGenerating && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-8 border border-gray-200 dark:border-gray-700 text-center">
              <PenTool className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                ابدأ بتوليد مقال جديد
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                أدخل الكلمة المفتاحية أو الموضوع واضغط على "توليد المقال" لإنشاء محتوى احترافي
              </p>
            </div>
          )}

          {isGenerating && (
            <div className="bg-white dark:bg-gray-800 rounded-xl p-8 border border-gray-200 dark:border-gray-700 text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                جاري توليد المقال...
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                يرجى الانتظار بينما نقوم بإنشاء مقال احترافي حول "{formData.keyword}"
              </p>
            </div>
          )}

          {generatedArticle && (
            <ArticlePreview article={generatedArticle} />
          )}
        </div>
      </div>
    </div>
  );
};

export default ArticleGenerator;